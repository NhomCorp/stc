import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import Link from "next/link";

export default async function DashboardPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.mustChangePassword) {
    redirect("/change-password");
  }

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <div style={styles.navLeft}>
          <span style={styles.brand}>💰 Sổ Thu Chi AI</span>
        </div>
        <div style={styles.navRight}>
          <span style={styles.userBadge}>
            👤 {user.fullName || user.username} ({user.role === "admin" ? "Quản trị viên" : "Thành viên"})
          </span>
          <form action="/api/auth/logout" method="POST" style={{ margin: 0 }}>
            <button type="submit" style={styles.logoutBtn}>
              Đăng xuất
            </button>
          </form>
        </div>
      </header>

      <main style={styles.main}>
        <div style={styles.welcomeCard}>
          <h2 style={styles.welcomeTitle}>Chào mừng trở lại, {user.fullName || user.username}!</h2>
          <p style={styles.welcomeDesc}>
            Hệ thống Sổ Thu Chi AI đang vận hành ổn định. Dữ liệu tài chính và báo cáo được đồng bộ an toàn.
          </p>

          <div style={styles.grid}>
            {user.role === "admin" && (
              <div style={styles.card}>
                <h3 style={styles.cardTitle}>👥 Quản trị Người dùng</h3>
                <p style={styles.cardDesc}>Tạo tài khoản mới, cấp mật khẩu tạm, đặt lại mật khẩu và phân quyền nội bộ.</p>
                <Link href="/admin/users" style={styles.linkButton}>
                  Truy cập Quản trị User →
                </Link>
              </div>
            )}

            <div style={styles.card}>
              <h3 style={styles.cardTitle}>📊 Báo cáo Thu Chi</h3>
              <p style={styles.cardDesc}>Theo dõi dòng tiền, doanh thu và chi phí đồng bộ từ Google Sheets & Meta Ads.</p>
              <span style={styles.badge}>Sắp phát hành (Giai đoạn 3)</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    minHeight: "100vh",
    backgroundColor: "#f8fafc",
    fontFamily: "system-ui, -apple-system, sans-serif",
  },
  header: {
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #e2e8f0",
    padding: "16px 24px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  brand: {
    fontSize: "18px",
    fontWeight: "700",
    color: "#0f172a",
  },
  navLeft: {
    display: "flex",
    alignItems: "center",
  },
  navRight: {
    display: "flex",
    alignItems: "center",
    gap: "16px",
  },
  userBadge: {
    fontSize: "14px",
    color: "#334155",
    backgroundColor: "#f1f5f9",
    padding: "6px 12px",
    borderRadius: "20px",
  },
  logoutBtn: {
    padding: "6px 12px",
    backgroundColor: "#ef4444",
    color: "#ffffff",
    border: "none",
    borderRadius: "6px",
    fontSize: "13px",
    fontWeight: "600",
    cursor: "pointer",
  },
  main: {
    maxWidth: "1000px",
    margin: "32px auto",
    padding: "0 20px",
  },
  welcomeCard: {
    backgroundColor: "#ffffff",
    borderRadius: "12px",
    padding: "28px",
    boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
  },
  welcomeTitle: {
    margin: "0 0 8px 0",
    fontSize: "24px",
    color: "#0f172a",
  },
  welcomeDesc: {
    margin: "0 0 24px 0",
    color: "#64748b",
    fontSize: "15px",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
    gap: "20px",
  },
  card: {
    border: "1px solid #e2e8f0",
    borderRadius: "8px",
    padding: "20px",
    backgroundColor: "#f8fafc",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
  },
  cardTitle: {
    margin: "0 0 8px 0",
    fontSize: "16px",
    color: "#1e293b",
  },
  cardDesc: {
    margin: "0 0 16px 0",
    fontSize: "13px",
    color: "#64748b",
    lineHeight: "1.5",
  },
  linkButton: {
    display: "inline-block",
    padding: "8px 14px",
    backgroundColor: "#2563eb",
    color: "#ffffff",
    textDecoration: "none",
    borderRadius: "6px",
    fontSize: "13px",
    fontWeight: "600",
    textAlign: "center",
  },
  badge: {
    display: "inline-block",
    padding: "4px 8px",
    backgroundColor: "#e2e8f0",
    color: "#64748b",
    borderRadius: "4px",
    fontSize: "12px",
    fontWeight: "500",
    width: "fit-content",
  },
};
