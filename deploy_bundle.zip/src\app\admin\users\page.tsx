import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import Link from "next/link";

export default async function AdminUsersPage() {
  const user = await getCurrentUser();

  if (!user || user.role !== "admin") {
    redirect("/login");
  }

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <div style={styles.navLeft}>
          <span style={styles.brand}>💰 Sổ Thu Chi AI</span>
          <span style={styles.breadcrumb}>Quản trị Người dùng</span>
        </div>
        <div style={styles.navRight}>
          <span style={styles.userBadge}>
            👤 {user.fullName || user.username} ({user.role})
          </span>
          <form action="/api/auth/logout" method="POST">
            <button type="submit" style={styles.logoutBtn}>
              Đăng xuất
            </button>
          </form>
        </div>
      </header>

      <main style={styles.main}>
        <div style={styles.headerRow}>
          <h1 style={styles.pageTitle}>Danh sách người dùng nội bộ</h1>
          <Link href="/admin/users/create" style={styles.createBtn}>
            + Tạo tài khoản mới
          </Link>
        </div>

        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead style={styles.thead}>
              <tr>
                <th style={styles.th}>Tên đăng nhập</th>
                <th style={styles.th}>Họ và tên</th>
                <th style={styles.th}>Email</th>
                <th style={styles.th}>Vai trò</th>
                <th style={styles.th}>Trạng thái</th>
                <th style={styles.th}>Phải đổi MK</th>
                <th style={styles.th}>Ngày tạo</th>
                <th style={styles.th}>Thao tác</th>
              </tr>
            </thead>
            <tbody style={styles.tbody}>
              {/* Dữ liệu sẽ được render động bởi client component */}
              <tr>
                <td colSpan={8} style={styles.empty}>
                  Đang tải danh sách người dùng...
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  container: {
    minHeight: "100vh",
    backgroundColor: "#f8fafc",
    fontFamily: "system-ui, -apple-system, sans-serif",
  },
  header: {
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #e2e8f0",
    padding: "16px 24px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  brand: {
    fontSize: "18px",
    fontWeight: "700",
    color: "#0f172a",
  },
  breadcrumb: {
    marginLeft: "12px",
    color: "#64748b",
    fontSize: "13px",
  },
  navLeft: {
    display: "flex",
    alignItems: "center",
  },
  navRight: {
    display: "flex",
    alignItems: "center",
    gap: "16px",
  },
  userBadge: {
    fontSize: "14px",
    color: "#334155",
    backgroundColor: "#f1f5f9",
    padding: "6px 12px",
    borderRadius: "20px",
  },
  logoutBtn: {
    padding: "6px 12px",
    backgroundColor: "#ef4444",
    color: "#ffffff",
    border: "none",
    borderRadius: "6px",
    fontSize: "13px",
    fontWeight: "600",
    cursor: "pointer",
  },
  main: {
    maxWidth: "1000px",
    margin: "32px auto",
    padding: "0 20px",
  },
  headerRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "20px",
  },
  pageTitle: {
    fontSize: "20px",
    fontWeight: "700",
    color: "#0f172a",
    margin: 0,
  },
  createBtn: {
    padding: "8px 16px",
    backgroundColor: "#2563eb",
    color: "#ffffff",
    borderRadius: "6px",
    textDecoration: "none",
    fontSize: "13px",
    fontWeight: "600",
  },
  tableContainer: {
    backgroundColor: "#ffffff",
    borderRadius: "8px",
    overflow: "hidden",
    boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
  },
  thead: {
    backgroundColor: "#f8fafc",
    borderBottom: "2px solid #e2e8f0",
  },
  th: {
    padding: "14px 16px",
    textAlign: "left",
    fontSize: "13px",
    fontWeight: "600",
    color: "#475569",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  },
  tbody: {
    fontSize: "14px",
  },
  tr: {
    borderBottom: "1px solid #e2e8f0",
  },
  td: {
    padding: "14px 16px",
  },
  empty: {
    padding: "40px 20px",
    textAlign: "center",
    color: "#64748b",
    fontSize: "14px",
  },
};
