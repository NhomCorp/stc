import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export default async function ProtectedLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  // Bắt buộc đổi mật khẩu lần đầu
  if (user.mustChangePassword) {
    // Để tránh vòng lặp, ta sẽ kiểm tra xem đã ở /change-password chưa
    // Nhưng vì (protected) có thể bao gồm /change-password, ta xử lý khéo hơn ở page hoặc tách layout.
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* Navbar mẫu */}
      <header className="bg-white shadow-sm px-6 py-4 flex justify-between items-center">
        <h1 className="font-bold text-xl text-blue-600">Sổ Thu Chi</h1>
        <div className="flex gap-4 items-center">
          <span>Xin chào, <strong>{user.fullName || user.username}</strong></span>
          <form action="/api/auth/logout" method="POST">
            {/* Dùng form post cho nút đăng xuất cơ bản (hoặc client component) */}
          </form>
        </div>
      </header>
      
      <main className="p-6 max-w-7xl mx-auto">
        {children}
      </main>
    </div>
  );
}
